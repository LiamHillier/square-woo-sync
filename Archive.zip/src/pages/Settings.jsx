import General from './settings/General';
export default function Settings() {
	return <General />;
}
